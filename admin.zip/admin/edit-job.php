<?php
// Include database connection
require_once '../includes/db_connect.php';

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

// Check if job ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: manage-careers.php');
    exit;
}

$jobId = $_GET['id'];

// Get job details
try {
    $stmt = $conn->prepare("SELECT * FROM job_listings WHERE id = :id");
    $stmt->bindParam(':id', $jobId, PDO::PARAM_INT);
    $stmt->execute();
    $job = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$job) {
        $_SESSION['error_message'] = "Job listing not found";
        header('Location: manage-careers.php');
        exit;
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching job details: " . $e->getMessage();
    header('Location: manage-careers.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $title = trim($_POST['title'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $job_type = trim($_POST['job_type'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $responsibilities = trim($_POST['responsibilities'] ?? '');
    $requirements = trim($_POST['requirements'] ?? '');
    
    // Basic validation
    if (empty($title) || empty($department) || empty($location) || empty($job_type) || empty($description)) {
        $_SESSION['error_message'] = "All required fields must be filled out";
    } else {
        try {
            $stmt = $conn->prepare("UPDATE job_listings SET 
                                    title = :title, 
                                    department = :department, 
                                    location = :location, 
                                    job_type = :job_type, 
                                    description = :description, 
                                    responsibilities = :responsibilities, 
                                    requirements = :requirements 
                                    WHERE id = :id");
            
            $stmt->bindParam(':title', $title, PDO::PARAM_STR);
            $stmt->bindParam(':department', $department, PDO::PARAM_STR);
            $stmt->bindParam(':location', $location, PDO::PARAM_STR);
            $stmt->bindParam(':job_type', $job_type, PDO::PARAM_STR);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $stmt->bindParam(':responsibilities', $responsibilities, PDO::PARAM_STR);
            $stmt->bindParam(':requirements', $requirements, PDO::PARAM_STR);
            $stmt->bindParam(':id', $jobId, PDO::PARAM_INT);
            
            $stmt->execute();
            
            $_SESSION['success_message'] = "Job listing updated successfully";
            header('Location: manage-careers.php');
            exit;
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error updating job listing: " . $e->getMessage();
        }
    }
}

// Page title
$pageTitle = "Edit Job Listing - Admin Dashboard";
include 'includes/navbar.php';
include 'includes/sidebar.php';
?>
<link rel="stylesheet" href="./css/admin.css">

<div class="container mx-auto px-4 py-8">
    <div class="mb-6">
        <a href="manage-careers.php" class="text-blue-500 hover:underline flex items-center">
            <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Back to Job Listings
        </a>
    </div>

    <h1 class="text-2xl font-bold mb-6">Edit Job Listing</h1>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <div class="bg-white shadow-md rounded-lg p-6">
        <form action="edit-job.php?id=<?php echo $jobId; ?>" method="post">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label for="title" class="block text-gray-700 font-medium mb-2">Job Title *</label>
                    <input type="text" id="title" name="title" required value="<?php echo htmlspecialchars($job['title']); ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div>
                    <label for="department" class="block text-gray-700 font-medium mb-2">Department *</label>
                    <select id="department" name="department" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Department</option>
                        <option value="SALES" <?php echo $job['department'] === 'SALES' ? 'selected' : ''; ?>>SALES</option>
                        <option value="MARKETING" <?php echo $job['department'] === 'MARKETING' ? 'selected' : ''; ?>>MARKETING</option>
                        <option value="OPERATION" <?php echo $job['department'] === 'OPERATION' ? 'selected' : ''; ?>>OPERATION</option>
                        <option value="ACCOUNT & FINANCE" <?php echo $job['department'] === 'ACCOUNT & FINANCE' ? 'selected' : ''; ?>>ACCOUNT & FINANCE</option>
                        <option value="TRAINERS" <?php echo $job['department'] === 'TRAINERS' ? 'selected' : ''; ?>>TRAINERS</option>
                    </select>
                </div>
                
                <div>
                    <label for="location" class="block text-gray-700 font-medium mb-2">Location *</label>
                    <select id="location" name="location" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Location</option>
                        <option value="NAGPUR" <?php echo $job['location'] === 'NAGPUR' ? 'selected' : ''; ?>>NAGPUR</option>
                        <option value="PUNE, WAKAD" <?php echo $job['location'] === 'PUNE, WAKAD' ? 'selected' : ''; ?>>PUNE, WAKAD</option>
                        <option value="PUNE, KOTHRUD" <?php echo $job['location'] === 'PUNE, KOTHRUD' ? 'selected' : ''; ?>>PUNE, KOTHRUD</option>
                        <option value="INDORE" <?php echo $job['location'] === 'INDORE' ? 'selected' : ''; ?>>INDORE</option>
                    </select>
                </div>
                
                <div>
                    <label for="job_type" class="block text-gray-700 font-medium mb-2">Job Type *</label>
                    <select id="job_type" name="job_type" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Job Type</option>
                        <option value="FULL TIME" <?php echo $job['job_type'] === 'FULL TIME' ? 'selected' : ''; ?>>FULL TIME</option>
                        <option value="PART TIME" <?php echo $job['job_type'] === 'PART TIME' ? 'selected' : ''; ?>>PART TIME</option>
                        <option value="CONTRACT" <?php echo $job['job_type'] === 'CONTRACT' ? 'selected' : ''; ?>>CONTRACT</option>
                        <option value="INTERNSHIP" <?php echo $job['job_type'] === 'INTERNSHIP' ? 'selected' : ''; ?>>INTERNSHIP</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-6">
                <label for="description" class="block text-gray-700 font-medium mb-2">Job Description *</label>
                <textarea id="description" name="description" rows="5" required
                          class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($job['description']); ?></textarea>
            </div>
            
            <div class="mb-6">
                <label for="responsibilities" class="block text-gray-700 font-medium mb-2">Responsibilities</label>
                <textarea id="responsibilities" name="responsibilities" rows="5"
                          class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($job['responsibilities'] ?? ''); ?></textarea>
                <p class="text-sm text-gray-500 mt-1">Enter each responsibility on a new line</p>
            </div>
            
            <div class="mb-6">
                <label for="requirements" class="block text-gray-700 font-medium mb-2">Requirements</label>
                <textarea id="requirements" name="requirements" rows="5"
                          class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($job['requirements'] ?? ''); ?></textarea>
                <p class="text-sm text-gray-500 mt-1">Enter each requirement on a new line</p>
            </div>
            
            <div class="flex justify-end">
                <button type="submit" class="bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition-colors">
                    Update Job Listing
                </button>
            </div>
        </form>
    </div>
</div>

