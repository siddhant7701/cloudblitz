<?php
// Include database connection
require_once '../includes/db_connect.php';

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

// Check if job ID is provided
if (!isset($_GET['job_id']) || empty($_GET['job_id'])) {
    header('Location: manage-careers.php');
    exit;
}

$jobId = $_GET['job_id'];

// Get job details
try {
    $stmt = $conn->prepare("SELECT title FROM job_listings WHERE id = :id");
    $stmt->bindParam(':id', $jobId, PDO::PARAM_INT);
    $stmt->execute();
    $job = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$job) {
        $_SESSION['error_message'] = "Job listing not found";
        header('Location: manage-careers.php');
        exit;
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching job details: " . $e->getMessage();
    header('Location: manage-careers.php');
    exit;
}

// Get applications for this job
try {
    $stmt = $conn->prepare("SELECT * FROM job_applications WHERE job_id = :job_id ORDER BY applied_at DESC");
    $stmt->bindParam(':job_id', $jobId, PDO::PARAM_INT);
    $stmt->execute();
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $applications = [];
    $_SESSION['error_message'] = "Error fetching applications: " . $e->getMessage();
}

// Handle application status update
if (isset($_POST['update_status']) && isset($_POST['application_id']) && isset($_POST['status'])) {
    $applicationId = $_POST['application_id'];
    $status = $_POST['status'];
    
    try {
        $stmt = $conn->prepare("UPDATE job_applications SET status = :status, updated_at = NOW() WHERE id = :id");
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->bindParam(':id', $applicationId, PDO::PARAM_INT);
        $stmt->execute();
        
        $_SESSION['success_message'] = "Application status updated successfully";
        header("Location: view-applications.php?job_id=$jobId");
        exit;
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error updating application status: " . $e->getMessage();
    }
}

// Handle application deletion
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $applicationId = $_GET['delete'];
    
    try {
        // First, get the resume path to delete the file
        $stmt = $conn->prepare("SELECT resume_path FROM job_applications WHERE id = :id");
        $stmt->bindParam(':id', $applicationId, PDO::PARAM_INT);
        $stmt->execute();
        $application = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($application && file_exists($application['resume_path'])) {
            unlink($application['resume_path']); // Delete the resume file
        }
        
        // Then delete the application record
        $stmt = $conn->prepare("DELETE FROM job_applications WHERE id = :id");
        $stmt->bindParam(':id', $applicationId, PDO::PARAM_INT);
        $stmt->execute();
        
        $_SESSION['success_message'] = "Application deleted successfully";
        header("Location: view-applications.php?job_id=$jobId");
        exit;
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error deleting application: " . $e->getMessage();
    }
}

// Page title
$pageTitle = "Applications for " . htmlspecialchars($job['title']) . " - Admin Dashboard";
include 'includes/navbar.php';
include 'includes/sidebar.php';
?>
<link rel="stylesheet" href="./css/admin.css">

<div class="container mx-auto px-4 py-8">
    <div class="mb-6">
        <a href="manage-careers.php" class="text-blue-500 hover:underline flex items-center">
            <svg class="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Back to Job Listings
        </a>
    </div>

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Applications for: <?php echo htmlspecialchars($job['title']); ?></h1>
        <div class="text-sm text-gray-500">
            Total Applications: <span class="font-bold"><?php echo count($applications); ?></span>
        </div>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4" role="alert">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <?php if (count($applications) > 0): ?>
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Applicant</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resume</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Applied On</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($applications as $application): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($application['name']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-500">
                                    <div><?php echo htmlspecialchars($application['email']); ?></div>
                                    <div><?php echo htmlspecialchars($application['phone']); ?></div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if (isset($application['resume_path']) && file_exists($application['resume_path'])): ?>
                                    <a href="<?php echo htmlspecialchars($application['resume_path']); ?>" target="_blank" class="text-orange-500 hover:underline">
                                        View Resume
                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-500">Resume not available</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-500">
                                    <?php echo date('M d, Y', strtotime($application['applied_at'])); ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                    <?php 
                                    $status = isset($application['status']) ? $application['status'] : 'Pending';
                                    switch ($status) {
                                        case 'Reviewed':
                                            echo 'bg-blue-100 text-blue-800';
                                            break;
                                        case 'Shortlisted':
                                            echo 'bg-green-100 text-green-800';
                                            break;
                                        case 'Rejected':
                                            echo 'bg-red-100 text-red-800';
                                            break;
                                        case 'Interviewed':
                                            echo 'bg-purple-100 text-purple-800';
                                            break;
                                        default:
                                            echo 'bg-yellow-100 text-yellow-800'; // Pending
                                    }
                                    ?>">
                                    <?php echo htmlspecialchars($status); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <button onclick="openStatusModal('<?php echo $application['id']; ?>')" class="text-blue-600 hover:text-blue-900">
                                        Update Status
                                    </button>
                                    <a href="view-applications.php?job_id=<?php echo $jobId; ?>&delete=<?php echo $application['id']; ?>" 
                                       class="text-red-600 hover:text-red-900" 
                                       onclick="return confirm('Are you sure you want to delete this application? This will also delete the resume file.')">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Status Update Modal -->
        <div id="statusModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center">
            <div class="bg-white rounded-lg p-6 max-w-md w-full">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Update Application Status</h3>
                <form action="view-applications.php?job_id=<?php echo $jobId; ?>" method="post">
                    <input type="hidden" name="application_id" id="application_id" value="">
                    <input type="hidden" name="update_status" value="1">
                    
                    <div class="mb-4">
                        <label for="status" class="block text-gray-700 font-medium mb-2">Status</label>
                        <select id="status" name="status" required
                                class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500">
                            <option value="Pending">Pending</option>
                            <option value="Reviewed">Reviewed</option>
                            <option value="Shortlisted">Shortlisted</option>
                            <option value="Interviewed">Interviewed</option>
                            <option value="Rejected">Rejected</option>
                        </select>
                    </div>
                    
                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="closeStatusModal()" 
                                class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                            Cancel
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600">
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
            function openStatusModal(applicationId) {
                document.getElementById('application_id').value = applicationId;
                document.getElementById('statusModal').classList.remove('hidden');
            }
            
            function closeStatusModal() {
                document.getElementById('statusModal').classList.add('hidden');
            }
        </script>
    <?php else: ?>
        <div class="bg-white shadow-md rounded-lg p-8 text-center">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            <h3 class="mt-2 text-sm font-medium text-gray-900">No applications</h3>
            <p class="mt-1 text-sm text-gray-500">No one has applied for this position yet.</p>
        </div>
    <?php endif; ?>
</div>

